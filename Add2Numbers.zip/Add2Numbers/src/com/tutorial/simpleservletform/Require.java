package com.tutorial.simpleservletform;

public interface Require {
	public String sum(String s1, String s2);
}
